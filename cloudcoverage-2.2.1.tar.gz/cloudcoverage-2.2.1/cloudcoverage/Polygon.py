class Polygon:
    
    coords = []
    
    def __init__(coords):
        self.coords = coords
    
    def sort(self):
        for i in range(len(coords - 1)):
            if coords[i][0] > coords[i][0]
            