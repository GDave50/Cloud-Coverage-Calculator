from PIL import Image, ImageColor, ImageDraw, ImageFont
import Rectangle
from shapely.geometry import Polygon
import os
import waterspoutalert